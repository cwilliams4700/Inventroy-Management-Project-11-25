-- Create database and tables
 CREATE DATABASE IF NOT EXISTS inventory_system;
 USE inventory_system;
 CREATE TABLE users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','moderator','user') DEFAULT 'user'
);
ALTER TABLE items
RENAME COLUMN name to item_name;
DROP TABLE items;
 CREATE TABLE IF NOT EXISTS items (
 item_id INT AUTO_INCREMENT PRIMARY KEY,
 item_name VARCHAR(150) NOT NULL,
 quantity_in_stock INT DEFAULT 0
 );
-- Sample data
INSERT INTO items (item_name, quantity_in_stock) 
VALUES
 ('Laptop',10),
 ('Headphones',30),
 ('T-shirt',100),
 ('Bananas',50);
 
 INSERT INTO users (username, password, role)
VALUES ('admin', '$2y$10$NQo4RfAH9n9un6x3NCrTn.Zr0VEBn2bLawSlVr3vndS5IBC9qPP1.', 'admin');